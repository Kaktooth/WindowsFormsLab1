﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pr_1
{
    public partial class Form1 : Form
    {
        private int checkedAmount = 0;
        private int amountValue = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                checkedAmount++;
                textBox4.Text = checkedAmount.ToString();
                amountValue += 125;
                textBox5.Text = amountValue.ToString();
            }
            if (checkBox1.Checked == false)
            {
                checkedAmount--;
                textBox4.Text = checkedAmount.ToString();
                amountValue -= 125;
                textBox5.Text = amountValue.ToString();
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                checkedAmount++;
                textBox4.Text = checkedAmount.ToString();
                amountValue += 140;
                textBox5.Text = amountValue.ToString();
            }
            if (checkBox2.Checked == false)
            {
                checkedAmount--;
                textBox4.Text = checkedAmount.ToString();
                amountValue -= 140;
                textBox5.Text = amountValue.ToString();
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                checkedAmount++;
                textBox4.Text = checkedAmount.ToString();
                amountValue += 15;
                textBox5.Text = amountValue.ToString();
            }
            if (checkBox3.Checked == false)
            {
                checkedAmount--;
                textBox4.Text = checkedAmount.ToString();
                amountValue -= 15;
                textBox5.Text = amountValue.ToString();
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                checkedAmount++;
                textBox4.Text = checkedAmount.ToString();
                amountValue += 29;
                textBox5.Text = amountValue.ToString();
            }
            if (checkBox4.Checked == false)
            {
                checkedAmount--;
                textBox4.Text = checkedAmount.ToString();
                amountValue -= 29;
                textBox5.Text = amountValue.ToString();
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked == true)
            {
                checkedAmount++;
                textBox4.Text = checkedAmount.ToString();
                amountValue += 700;
                textBox5.Text = amountValue.ToString();
            }
            if (checkBox5.Checked == false)
            {
                checkedAmount--;
                textBox4.Text = checkedAmount.ToString();
                amountValue -= 700;
                textBox5.Text = amountValue.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool calculate = true; 
            if(textBox1.Text == "")
            {
                calculate = false;
                MessageBox.Show("Name not entered!");
            }
            if (checkBox1.Checked==false&& checkBox2.Checked == false&& checkBox3.Checked == false&& checkBox4.Checked == false&& checkBox5.Checked == false)
            {
                calculate = false;
                MessageBox.Show("Services not specified!");
            }
            if (calculate == true)
            {
                Form2 f = new Form2();
                f.textBox1.Text = textBox1.Text;
                f.textBox2.Text = textBox2.Text;
                f.textBox3.Text = textBox3.Text;
                f.textBox4.Text = textBox4.Text;
                if(textBox3.Text == "1")
                {
                    f.textBox5.Text = textBox5.Text;
                }
                else if (textBox3.Text == "2")
                {
                    f.textBox5.Text = ((float)amountValue * 1.2f).ToString();
                }
                else if (textBox3.Text == "3")
                {
                    f.textBox5.Text = ((float)amountValue * 1.3f).ToString();
                }
                if (checkBox1.Checked == true)
                {
                    f.textBox6.Text += checkBox1.Text+" ";
                }
                if (checkBox2.Checked == true)
                {
                    f.textBox6.Text += checkBox2.Text + " ";
                }
                if (checkBox3.Checked == true)
                {
                    f.textBox6.Text += checkBox3.Text + " ";
                }
                if (checkBox4.Checked == true)
                {
                    f.textBox6.Text += checkBox4.Text + " ";
                }
                if (checkBox5.Checked == true)
                {
                    f.textBox6.Text += checkBox5.Text + " ";
                }

                f.Show();
            }
        }
    }
}
