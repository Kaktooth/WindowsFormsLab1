﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace App4_
{
    public partial class Form1 : Form
    {
        private int labelCount = 0;
        private int x = 0;
        private int y = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Label namelabel = new Label();
            namelabel.Location = new Point(x, y);
            y += 22;
            namelabel.Text = "label" + ++labelCount;
            namelabel.AutoSize = false;
            namelabel.Click += label_Click;

            this.Controls.Add(namelabel);
        }
        private void label_Click(object sender, EventArgs e)
        {
            Control s = (Control)sender;
            label2.Text = s.Text.Replace("label", "");
        }
    }
}