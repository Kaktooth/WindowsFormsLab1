﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ex2
{
    public partial class nFom : ex2.Form1
    {
        public nFom()
        {
            InitializeComponent();
        }
    }
}
